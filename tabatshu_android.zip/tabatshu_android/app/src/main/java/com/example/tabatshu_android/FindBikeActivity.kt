package com.example.tabatshu_android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FindBikeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_bike) // 적절한 레이아웃 파일 설정
    }
}
